SimYukkuri 2021
===

A Yukkuri Simulator

This project is a continuation of the original game developed my Mimisuke.

https://ja.osdn.net/projects/simyukkuri/

System Requirements
---

JDK 8 or later for development (after building only JRE 8 is required)
The JDK/JRE is mandatory

How To
---
You can run start_XGB.bat in the same folder to make it use XGB of memory.

For more information, please refer to the following repository.
https://github.com/sin-orb/Simyukkuri2021

Changes from 20210605
Bug fixes
1.Fixed an issue where the "<<" button in the log was not always effect.
2.Fixed an issue where the yukkuri almost always would have the stupid tongue.
3.Fixed an issue where you couldn't pull the needle out of a corpse with a needle stuck in it.
4.Fixed an issue where force-feeding would increase a corpse's satiety level.

Specification changes
1.Stopped reading the image data of yukkuris the startup of application for people without high PC specs.
  *It will read the image data when a yukkuri is first created.
  *You will be surprised at how fast the app starts up.
2.The message body is now the same color as the message frame.
3.****Useful functions recommended by the developer @sin_orb****
  *The yukkuri specified on the status window side is now also specified on the screen side.
4.halfway through the process of converting the save data to JSON, and halfway through referencing the library Jackson.
�@*Still using Java default for save/load.
�@*Changed the internal structure quite a bit to eliminate circular references, so there's a possibility of a bug storm...


Changes from 20210502
Bugfix
1. Fixed an issue where favorite items would continue to work and not change their sleeping location when a yukkuri becomes or stops being poo-poo slave.
2.Fixed an issue where the hybrid yukkuri's two original types would be added to the sisters/children list if it existed.
3.Fixed an issue where various attributes of the original Reimu would be lost when it was transformed into a Deibu.
4.Fixed an issue where a live fruit-yukkuri would sometimes remain in the air instead of falling when cleaning the stalk.
5.Fixed an issue where a live fruit-yukkuri run away in a panic.
6.Poo-poo ampoules and poison ampoules no longer work on dead yukkuris.
7.Dead yukkuris no longer grow.
8.Needle commands can now be totalized with the Shift key. (Thanks for @Mr.64)
9.Yukkuris can now carry the little ones normally.
10.Fixed an issue where you can increase Dosu-marisa as you like using the Hybrid yukkuri System.Only one Dosu-marisa is allowed on one map.
11.Fixed an issue where a sperm ampoule would impregnate an embryonic castrated slow, even though it was supposed to be castrated.
12.Fixed an issue where stalks with no parents and only shadows would not be cleaned even if you specified "All".
13.Fixed an issue where Rapers would run away in a panic without raping when Remillia exists.
14.Fixed an issue where the player's items would go mad after loading.
15.Fixed an issue where a lot of errors would occur when trying to totalize womb castration and stalk castration. (Thanks for @Mr.64)
16.Fixed an issue that prevented the proud child event from occuring. (Thanks for @Mr.64)
17.Fixed an issue that prevented the mourning event from occurring. (Thanks for @Mr.64)
18.Fixed an issue where the random movement yukkuris always does would sometimes only move up and down. (Thanks for @Kirisam)
19.Fixed an issuem where the event convocation would not end.
20.Fixed an issue where you can't cut off peni-peni to a hollowed-out-eyeballs yukkuri.
21.Fixed an issue where cutting off peni-peni of a sleeping yukkuri would cause nothing to happen at first glance, and then the penipenis would be cut off after the yukkuri woke up.
22.Fixed an issue where the build.bat in the repository was broken and could not be built. (Thanks for @Vannilla)


Specification Changes
1.Starvation-inducing ampoules have been enhanced.
2.The probability of the begging for life event has been greatly increased.
3.Marriage event messages for Shithead Marisa and Super-shithead Marisa didn't match the image, so I changed them to be more "shithead-male".
 (e.g.: Confession OK: "Yuu//I understand... Marisa wants to spend time with Reimu too! -> "...That's okay. I'll use Reimu's mamu-mamu as Mr.Marisa's peni-peni-sack, so be grateful!"
 and When approached refreshing, "Okay, come//" -> "Whadz iz diiiiiiss! (Mr.Marisa's going to make a female-exstacy!!!)"::::CAUTION::::
This is a Japanese version of the story, so the lines themselves are not translated into English.
4.Added "Next ID", "Previous ID", "First", "Last", "Random", "Partner", "Child", "Elder-Sis", "Little-Sis", "Father", and "Mother" buttons to the status screen.
4-1.The next ID and previous ID are cycled.
4-2.Children, Elder-Sist, and little-Sis will be shown of the oldest ones in the list (the ones with the youngest ID).
5.The ID is now an inputtable item on the status screen.
5-1.When you enter an ID and click "Refresh"(it's not yukkuri's "Refreshed!!!"lol), the yukkuri's information of the entered ID will be displayed.
5-2.The other buttons are also searched based on the entered ID.
6.When confessing, if the target is not single, it will now give up at 50%.
6-1.However, yukkuri is a fool and often ends up targeting married one and sinking.
7.The number of bytes in saved data has been reduced.
7-1.The world map list and other properties are no longer stored as properties.
7-2.But there is still a bug that the save file cannot be loaded. Sorry about that.
8.The ratio of personality (super nice: nice: normal: shithead: super shithead) is now 1:2:3:2:1 when randomly creating a yukkuri.
9.Changed resources to be out of the SimYukkri.jar. The menu is now displayed in English when the app is opened in an English environment. (Thanks for @Vannilla, Thanks for @DELPHI. translating)
9-1.If you put simyukkuri.<locale>.properties in the resources folder the same layer of the SimYukkuri.jar, the menu will be in that locale.
